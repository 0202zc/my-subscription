create
    definer = root@localhost procedure proc_addCrawler(IN crawlerName varchar(45), IN filePath varchar(100),
                                                       IN enabled tinyint, OUT id bigint)
begin
    insert into db_mail_send.crawlers (crawler_name, file_path, enabled) values (crawlerName, filePath, enabled);
    select last_insert_id() into id;
end;

