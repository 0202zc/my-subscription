create
    definer = root@localhost procedure proc_addContent(IN cnt mediumtext, IN serviceId bigint)
BEGIN
    -- 定义一个变量来保存该记录是否存在
    declare num int;
    declare old_content mediumtext;
    -- 这条sql，就是查询对应的记录有多少条，注意 into num 这两句话，就是把count(*) 查出的值，赋给到num中
    select COUNT(*) into num from services_content where service_id = serviceId;
    select content into old_content from services_content where service_id = serviceId;
    -- 接下来的就是判断了，注意，判断是否等于，只有一个等于号
    if(num = 0)
    -- 等于号之后，还要写一个Then，代表条件成立后要执行的sql
        Then
        insert into services_content (content, service_id) values (cnt,serviceId);
    -- else可以直接用，不需要加then
    elseif(old_content <> cnt)
        Then
        update services_content set content = cnt where service_id = serviceId;
    -- 但是当if使用完之后，一定要写end if，代表着if的条件判断结束了
    end if;
end;

