create
    definer = root@localhost procedure proc_addService(IN serviceName varchar(45), IN note text, IN enabled tinyint,
                                                       OUT id bigint)
begin
    insert into db_mail_send.services (service_name, note, enabled) values (serviceName, note, enabled);
    select last_insert_id() into id;
end;

