create
    definer = root@localhost procedure proc_addCrawlerWithService(IN crawlerName varchar(45), IN filePath varchar(100),
                                                                  IN enabled tinyint, IN serviceId bigint,
                                                                  OUT id bigint)
begin
    declare new_id bigint;
    insert into db_mail_send.crawlers (crawler_name, file_path, enabled) values (crawlerName, filePath, enabled);
    select last_insert_id() into new_id;
    insert into db_mail_send.service_crawler (service_id, crawler_id) values (serviceId, new_id);
    select last_insert_id() into id;
end;

